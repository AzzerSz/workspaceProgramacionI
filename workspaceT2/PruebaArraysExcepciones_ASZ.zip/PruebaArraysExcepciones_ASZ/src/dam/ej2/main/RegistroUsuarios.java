package dam.ej2.main;

import java.util.Scanner;

import dam.ej2.pojos.Perfil;

public class RegistroUsuarios {

	static final int MIN_NCONTACT = 0;
	static final int MAX_NCONTACT = 100000;
	static final int MAX_CHAR = 45;
	static final int TAM = 10;
	
	static Perfil[] usuario;
	
	public static void main(String[] args) {
		
		usuario = new Perfil[TAM];
		
		rellenarUsuario();
		
		mostrarUsuario();
		
		analisisContactos();

	}

	private static void mostrarUsuario() {
		for (int i = 0; i < usuario.length; i++) {
			System.out.println("*** " + (i+1) + "� USUARIO ***");
			System.out.println(usuario[i]);
		}
		
	}

	private static void analisisContactos() {
		Perfil maxContac = new Perfil("", "", "", 0);
		
		for (int i = 0; i < usuario.length; i++) {
			if (usuario[i].getCiudad().equalsIgnoreCase("Madrid")) {
				if (maxContac.getNContactos() < usuario[i].getNContactos() ) {
						maxContac = usuario[i];
				}
			}
		}
		
		System.out.println("El usuario / perfil con m�s contactos de Madrid es\n" + maxContac);
		
	}

	private static void rellenarUsuario() {
		
		String nombre = "";
		String puesto = "";
		String ciudad = "";
		int nContactos = 0;
		
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < usuario.length; i++) {
			System.out.println("*** " + (i+1) + "� USUARIO ***");
			System.out.println("Introduce el nombre del usuario");
			nombre = restriccionCarac(sc);
			System.out.println("Introduce el puesto del usuario");
			puesto = restriccionCarac(sc);
			System.out.println("Introduce la ciudad");
			ciudad = comprobarCiudad(sc);
			System.out.println("Introduce la cantidad de contactos");
			nContactos = comprobarContactos(sc);
			
			usuario[i] = new Perfil(nombre, puesto, ciudad, nContactos);
		}
		
		sc.close();
		
	}

	private static int comprobarContactos(Scanner sc) {
		int nContactos = 0;
		boolean valNoVal = true;
		
		while (valNoVal) {
			try {
				nContactos = Integer.parseInt(sc.nextLine());
				
				if (nContactos < MIN_NCONTACT || nContactos > MAX_NCONTACT) {
					throw new Exception("Introduce un valor comprendido entre " + MIN_NCONTACT + " y " + MAX_NCONTACT);
				}
				
				valNoVal = false;
				
			} catch (NumberFormatException e) {
				System.out.println("Introduce un n�mero entero");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return nContactos;
	}

	private static String comprobarCiudad(Scanner sc) {
		String ciudad = "";
		boolean valNoVal = true;
		
		while (valNoVal) {
				ciudad = sc.nextLine();

				if (ciudad.equalsIgnoreCase("Madrid") || ciudad.equalsIgnoreCase("Barcelona")
						|| ciudad.equalsIgnoreCase("M�laga") || ciudad.equalsIgnoreCase("Valladolid")) {
					valNoVal = false;
				} else {
					System.out.println("La ciudad tiene que ser Madrid, Barcelona, M�laga o Valladolid");
				}
		}
		
		return ciudad;
	}

	// Se podr�a agregar un par�metro String para que repitiese el siso de Introduce (...) durante el bucle
	private static String restriccionCarac(Scanner sc) {
		String nombre = null;
		boolean valNoVal = true;
		
		while (valNoVal) {
			try {
				nombre = sc.nextLine();

				if (nombre.length() >= MAX_CHAR) {
					throw new Exception("Debes introducir menos de " + MAX_CHAR + " caracteres");
				}
				
				valNoVal = false;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return nombre;
		
	}

}
