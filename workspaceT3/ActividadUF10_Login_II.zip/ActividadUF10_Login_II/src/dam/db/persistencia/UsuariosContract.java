package dam.db.persistencia;

public class UsuariosContract {
	
	public static final String TAB_USUARIOS = "USUARIOS";
	public static final String COL_USER = "USUARIO";
	public static final String COL_PWD = "PASSWORD";

}
