package dam.db.persistencia;

public class ParticipantesContract {

	public static final String TBL_PARTICIPANTES = "PARTICIPANTES";
	public static final String COL_PAIS = "PAIS";
	public static final String COL_INTERPRETE = "INTERPRETE";
	public static final String COL_CANCION = "CANCION";
	public static final String COL_PUNTOS_JUR = "PUNTOS_JURADO";
	public static final String COL_PUNTOS_PUBL = "PUNTOS_PUBLICO";
	public static final String COL_PUNTOS_TOT = "PUNTOS";
	
}
