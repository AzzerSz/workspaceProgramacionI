package dam.model;

public class Videojuego {
	
	public static final String[] PLATAFORMAS = {"PS5", "Nintendo Switch", "Nintendo DS", "XBox", "PC"};
	
	private String titulo;
	private String plataforma;
	private int codPegi;
	private String prestadoA;
	
	public Videojuego(String titulo, String plataforma, int codPegi, String prestadoA) {
		this.titulo = titulo;
		this.plataforma = plataforma;
		this.codPegi = codPegi;
		this.prestadoA = prestadoA;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public int getCodPegi() {
		return codPegi;
	}

	public String getPrestadoA() {
		return prestadoA;
	}
	
	
	

}
