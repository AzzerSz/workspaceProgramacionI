package dam;
import java.awt.EventQueue;

import dam.control.GestorVideojuegosControl;
import dam.model.FuenteDatos;
import dam.view.PAddVideojuegos;
import dam.view.PConsultaVideojuegos;
import dam.view.VPGestorVideojuegos;

public class InicioGestionVideojuegos {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				VPGestorVideojuegos vp = new VPGestorVideojuegos();
				PAddVideojuegos pav = new PAddVideojuegos();
				PConsultaVideojuegos pcv = new PConsultaVideojuegos();
				
				FuenteDatos datos = new FuenteDatos();
				
				GestorVideojuegosControl c = new GestorVideojuegosControl(vp, pav, pcv, datos);
				
				vp.setControlador(c);
				pav.setControlador(c);
				pcv.setControlador(c);
				
				vp.hacerVisible();
				
			}
		});

	}

}
