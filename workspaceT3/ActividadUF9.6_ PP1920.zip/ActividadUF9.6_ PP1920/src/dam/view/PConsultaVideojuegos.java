package dam.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dam.control.GestorVideojuegosControl;
import dam.model.Videojuego;

public class PConsultaVideojuegos extends JPanel {
	public static final String BTN_CONSULTAR = "Consultar Colecci�n";

	private static final String COLUMN_TIT = "T�TULO";
	private static final String COLUMN_PLA = "PLATAFORMA";
	private static final String COLUMN_COD = "C�DIGO PEGI";
	private static final String COLUMN_PRES = "PRESTADO A";
	
	private JTable tblVideojuegos;
	private JButton btnConsultar;
	private DefaultTableModel dtm;
	
	public PConsultaVideojuegos() {
		init();
	}

	private void init() {
		setLayout(null);
		
		setSize(VPGestorVideojuegos.PANEL_ANCHO, VPGestorVideojuegos.PANEL_ALTO);
		
		JLabel lblConsultarViedojuegos = new JLabel("Consultar Viedojuegos");
		lblConsultarViedojuegos.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblConsultarViedojuegos.setBounds(45, 45, 319, 29);
		add(lblConsultarViedojuegos);
		
		btnConsultar = new JButton(BTN_CONSULTAR);
		btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnConsultar.setBounds(284, 112, 217, 25);
		add(btnConsultar);
		
		JScrollPane scrpTabla = new JScrollPane();
		scrpTabla.setBounds(64, 181, 657, 285);
		add(scrpTabla);
		
		tblVideojuegos = new JTable();
		scrpTabla.setViewportView(tblVideojuegos);
		
		configurarTabla();
		
	}
	
	private void configurarTabla() {
		dtm = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		tblVideojuegos.setModel(dtm);
		
		dtm.addColumn(COLUMN_TIT);
		dtm.addColumn(COLUMN_PLA);
		dtm.addColumn(COLUMN_COD);
		dtm.addColumn(COLUMN_PRES);
		
		tblVideojuegos.getColumn(COLUMN_TIT).setPreferredWidth(175);
		tblVideojuegos.getColumn(COLUMN_PLA).setPreferredWidth(100);
		tblVideojuegos.getColumn(COLUMN_COD).setPreferredWidth(50);
		tblVideojuegos.getColumn(COLUMN_PRES).setPreferredWidth(100);
		
	}
	
	public void rellenarTabla(ArrayList<Videojuego> lista) {
		dtm.setRowCount(0);
		
		Object[] fila = new Object[4];
		
		for (Videojuego vj : lista) {
			fila[0] = vj.getTitulo();
			fila[1] = vj.getPlataforma();
			fila[2] = vj.getCodPegi();
			fila[3] = vj.getPrestadoA();
			
			dtm.addRow(fila);
		}
	}

	public void setControlador(GestorVideojuegosControl c) {
		btnConsultar.addActionListener(c);
	}
}
