package dam.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import dam.control.GestorVideojuegosControl;
import dam.model.Videojuego;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class PAddVideojuegos extends JPanel {
	public static final String BTN_GUARDAR = "Guardar Datos";
	
	private JTextField txtTitulo;
	private final ButtonGroup btngCodPegi = new ButtonGroup();
	private JTextField txtPrestadoA;
	private JComboBox<String> cmbPlataforma;
	private JRadioButton rdbtn3;
	private JRadioButton rdbtn7;
	private JRadioButton rdbtn12;
	private JRadioButton rdbtn18;
	private JButton btnGuardar;
	
	public PAddVideojuegos() {
		init();
	}

	private void init() {
		setLayout(null);
		
		setSize(VPGestorVideojuegos.PANEL_ANCHO, VPGestorVideojuegos.PANEL_ALTO);
		
		JLabel lblTitulo = new JLabel("A\u00F1adir Viedojuego");
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblTitulo.setBounds(45, 45, 319, 29);
		add(lblTitulo);
		
		JLabel lblNombre = new JLabel("T\u00EDtulo");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNombre.setBounds(97, 110, 111, 22);
		add(lblNombre);
		
		txtTitulo = new JTextField();
		txtTitulo.setToolTipText("Introduce el t\u00EDtulo del videojuego");
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtTitulo.setBounds(246, 109, 403, 25);
		add(txtTitulo);
		txtTitulo.setColumns(10);
		
		JLabel lblPlataforma = new JLabel("Plataforma");
		lblPlataforma.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPlataforma.setBounds(97, 175, 111, 22);
		add(lblPlataforma);
		
		cmbPlataforma = new JComboBox<String>();
		cmbPlataforma.setModel(new DefaultComboBoxModel<String>(Videojuego.PLATAFORMAS));
		cmbPlataforma.setFont(new Font("Tahoma", Font.PLAIN, 18));
		cmbPlataforma.setBounds(246, 174, 183, 25);
		add(cmbPlataforma);
		
		JLabel lblCodPegi = new JLabel("C\u00F3digo Pegi");
		lblCodPegi.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCodPegi.setBounds(97, 243, 127, 22);
		add(lblCodPegi);
		
		rdbtn3 = new JRadioButton("3");
		rdbtn3.setSelected(true);
		btngCodPegi.add(rdbtn3);
		rdbtn3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtn3.setBounds(255, 242, 68, 25);
		add(rdbtn3);
		
		rdbtn7 = new JRadioButton("7");
		btngCodPegi.add(rdbtn7);
		rdbtn7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtn7.setBounds(355, 242, 68, 25);
		add(rdbtn7);
		
		rdbtn12 = new JRadioButton("12");
		btngCodPegi.add(rdbtn12);
		rdbtn12.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtn12.setBounds(458, 242, 68, 25);
		add(rdbtn12);
		
		rdbtn18 = new JRadioButton("18");
		btngCodPegi.add(rdbtn18);
		rdbtn18.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtn18.setBounds(570, 242, 68, 25);
		add(rdbtn18);
		
		JLabel lblPrestadoA = new JLabel("Prestado a ");
		lblPrestadoA.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPrestadoA.setBounds(97, 312, 127, 22);
		add(lblPrestadoA);
		
		txtPrestadoA = new JTextField();
		txtPrestadoA.setToolTipText("Introduce la persona a qui\u00E9n se ha prestado");
		txtPrestadoA.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtPrestadoA.setColumns(10);
		txtPrestadoA.setBounds(246, 311, 403, 25);
		add(txtPrestadoA);
		
		btnGuardar = new JButton(BTN_GUARDAR);
		btnGuardar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnGuardar.setBounds(301, 396, 182, 25);
		add(btnGuardar);
	}
	
	public void setControlador(GestorVideojuegosControl c) {
		btnGuardar.addActionListener(c);
	}

	public Videojuego obtenerVideoJuego() {
		Videojuego vj = null;
		
		String titulo = txtTitulo.getText().trim();
		
		if (titulo.isEmpty()) {
			mostrarError("El t�tulo es obligatorio");
		} else {
			String plataforma = (String) cmbPlataforma.getSelectedItem();
			int codPegi = obtenerCodPegi();
			String prestadoA = txtPrestadoA.getText().trim();
			
			vj = new Videojuego(titulo, plataforma, codPegi, prestadoA);
		}
		return vj;
	}

	private int obtenerCodPegi() {
		int cod = Integer.parseInt(rdbtn3.getText());
		
		if (rdbtn7.isSelected()) {
			cod = Integer.parseInt(rdbtn7.getText());
		} else if (rdbtn12.isSelected()) {
			cod = Integer.parseInt(rdbtn12.getText());
		} else if (rdbtn18.isSelected()) {
			cod = Integer.parseInt(rdbtn18.getText());
		}
		return cod;
	}

	private void mostrarError(String error) {
		JOptionPane.showMessageDialog(this, error, "Error de datos", JOptionPane.ERROR_MESSAGE);
		
	}

	public void mostrarResultado(String mensaje) {
		JOptionPane.showMessageDialog(this, mensaje, "Resultado de la operaci�n", 
				JOptionPane.INFORMATION_MESSAGE);
		
	}

	public void limpiarComponentes() {
		txtTitulo.setText("");
		cmbPlataforma.setSelectedIndex(0);
		rdbtn3.setSelected(true);
		txtPrestadoA.setText("");
		
	}
}
