package dam.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import dam.model.FuenteDatos;
import dam.model.Videojuego;
import dam.view.PAddVideojuegos;
import dam.view.PConsultaVideojuegos;
import dam.view.VPGestorVideojuegos;

public class GestorVideojuegosControl implements ActionListener {
	
	VPGestorVideojuegos v;
	PAddVideojuegos pav;
	PConsultaVideojuegos pcv;
	FuenteDatos datos;

	public GestorVideojuegosControl(VPGestorVideojuegos v, PAddVideojuegos pav, PConsultaVideojuegos pcv,
			FuenteDatos datos) {
		this.v = v;
		this.pav = pav;
		this.pcv = pcv;
		this.datos = datos;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() instanceof JMenuItem) {
			
			if (e.getActionCommand().equals(VPGestorVideojuegos.MNTM_ADD)) {
				v.mostrarPanel(pav);
				
			} else if (e.getActionCommand().equals(VPGestorVideojuegos.MNTM_CONSULTA)) {
				v.mostrarPanel(pcv);
			
			} else if (e.getActionCommand().equals(VPGestorVideojuegos.MNTM_SALIR)) {
				int resp = JOptionPane.showConfirmDialog(v, "Se va a cerrar la aplicaci�n �Desea continuar?",
						"Confirmaci�n cierre de aplicaci�n", 
						JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
				
				if (resp == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
			
		} else if (e.getSource() instanceof JButton) {
			
			if (e.getActionCommand().equals(PAddVideojuegos.BTN_GUARDAR)) {
				Videojuego vj = pav.obtenerVideoJuego();
				
				if (vj != null) {
					datos.addVideojuego(vj);
					pav.mostrarResultado("Se guardado el videojuego correctamente");
					pav.limpiarComponentes();
				}
			} else if (e.getActionCommand().equals(PConsultaVideojuegos.BTN_CONSULTAR)) {
				pcv.rellenarTabla(datos.getColeccion());
				
			}
			
		}

	}

}
