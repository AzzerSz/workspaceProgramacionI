package Ejercicio1.otro;

public class Ejercicio1 {

	public static void main(String[] args) {
		for (int i = 0; i < 6*15; i += 6) {
			
			System.out.println(94 - i);
		}

	}

}
